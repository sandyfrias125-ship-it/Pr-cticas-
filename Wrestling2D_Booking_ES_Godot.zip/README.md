# Wrestling 2D - Booking (ES) (Godot 4)

Este proyecto es una base 2D *original* con:
- Modo Promotor (Booking): plantilla, cartelera, elegir ganador, simular show, progreso semanal, guardado.
- Combate 2D simple (golpe/patada/bloqueo/esquiva, vida y resistencia).
- Textos en español (editable en `data/localization.json`).

## Requisitos
- Godot 4.x (recomendado 4.2+)
- Para APK Android: export templates de Godot + Android SDK (Godot te guía en el menú Export).

## Cómo abrir
1. Abre Godot
2. Importa la carpeta del proyecto
3. Ejecuta (F5) para probar en PC

## Exportar a Android (APK)
1. `Project > Export...`
2. Add preset: Android
3. Configura:
   - Package / Unique Name
   - Keystore (debug o tu keystore)
4. Exporta APK

## Controles (PC)
A/D mover • J golpe • K patada • L bloquear • I esquivar • Esc volver

## Guardado
Se guarda en: `user://wr_save.json` (carpeta de usuario del dispositivo)
